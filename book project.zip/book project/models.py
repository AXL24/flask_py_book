import os

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import ForeignKey
db =SQLAlchemy()


#khời tạo các class ứng với csdl 
class Account(db.Model):
  __tablename__= "account"

  id = db.Column(db.Integer, primary_key=True)
  username = db.Column(db.String(50), nullable=False ) 
  password = db.Column(db.String(50), nullable=False)
  email= db.Column(db.String(50), nullable=True)
  phone = db.Column(db.String(50), nullable=True)


class Store(db.Model):
   __tablename__ = "store"
   
   isbn = db.Column (db.Integer, primary_key=True) 
   title = db.Column (db.String(50), nullable=False) 
   author = db.Column (db.String(50), nullable=False) 
   rating = db.Column (db.Integer)
   length = db.Column (db.String(50))
   
 
class Cart(db.Model):
  __tablename__= "cart"
  id=db.Column(db.Integer, primary_key=True)
  total=db.Column(db.String(50))
  purchase_date=db.Column(db.String(50))
  book_isbn=db.Column(db.Integer, ForeignKey('store.isbn'))
  account_id=db.Column(db.Integer, ForeignKey('account.id'))



 
