import os

from flask import Flask, session ,render_template, request, redirect, url_for , flash
from flask_session import Session
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker 
from models import*


app = Flask(__name__, template_folder='views')
app.config['DATABASE_URL'] ='postgresql://postgres:0964212618abc@localhost:5432/book'
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:0964212618abc@localhost:5432/book"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']= False


# cài đặt và kết nối tới database
db =SQLAlchemy(app)

app.config["SESSION_PERMANENT"] = False 
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
engine = create_engine('postgresql://postgres:0964212618abc@localhost:5432/book') 
Session = scoped_session(sessionmaker(bind=engine))


#render trang chính
@app.route("/")
def index():
    return render_template("index.html")


#2 route này được dùng để đăng ký thành viên, ( chức năng create)
@app.route("/register", methods=['Get', 'POST'])
def register():
    return render_template("register.html")


@app.route("/book", methods=['POST']) 
def book():
    username = request.form.get("username")
    password = request.form.get("password")
    email = request.form.get("email")
    phone = request.form.get("phone")  
    accounts = Account(username=username, password=password, email=email,phone=phone) 
    session= Session()
    session.add(accounts) 
    session.commit()
    return render_template("message.html", username=username)



#3 route này hiện việc render trang chính , nhằm phục vụ chức năng crud cho 3 database
@app.route("/users")
def users():
     session = Session()
     result = session.query(Account).order_by(Account.id)
     return render_template("users.html", result = result)


@app.route('/store')
def store():
    session = Session()
    all_books=session.query(Store).all()
    return render_template("store.html", books = all_books)


@app.route('/carts')
def carts():
    session = Session()
    all_carts=session.query(Cart).all()
    return render_template("carts.html", carts = all_carts)



#route này cho phép người dùng đã có tài khoản có thể đăng nhập
@app.route('/login', methods=['GET', 'POST'])
def login():
    
    username = request.form.get("username") 
    password = request.form.get("password")
    session = Session()
    result=session.query(Account).all()
    session.commit() 
    for result in result:
         
         if username == result.username and password == result.password :
                     

            return render_template("login.html", message= "Đăng nhập thành công")                
    else :
          
            
          return render_template("login.html", message= "Sai tài khoản hoặc mật khẩu")
    
    

#route phục vụ chức năng search
@app.route("/search")
def search():
     return render_template("search.html")



#3 route phục cho ra kết quả tìm kiếm từ form do người dùng nhập
@app.route("/bookresult", methods=['POST'])
def bookresult():

    isbn = request.form.get("isbn") 
    title = request.form.get("title") 
    author = request.form.get("author") 
    rating = request.form.get("rating") 
    length=request.form.get('length')
    session= Session()
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5= []
    results = session.query(Store).all()

    for i in results:

        if (title in i.title) is True:
            list1.append(i.isbn)
            list2.append(i.title)
            list3.append(i.author)
            list4.append(i.rating)
            list5.append(i.length)
    session.commit()
    return render_template("bookresult.html", count=len(list1), result1=list1, result2=list2, result3= list3, result4= list4, result5=list5)

@app.route("/userresult", methods=['POST'])
def userresult():

    id = request.form.get("id") 
    username = request.form.get("username") 
    email = request.form.get("email") 
    phone = request.form.get("phone") 
    
    session= Session()
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    
    results = session.query(Account).all()

    for i in results:

        if (username in i.username) is True:
            list1.append(i.id)
            list2.append(i.username)
            list3.append(i.email)
            list4.append(i.phone)
       
    session.commit()
    return render_template("userresult.html", count=len(list1), result1=list1, result2=list2, result3= list3, result4= list4 )
    

@app.route("/cartresult", methods=['POST'])
def cartresult():

    id = request.form.get("id") 
    total = request.form.get("total") 
    purchase_date = request.form.get("purchase_date") 
    book_isbn = request.form.get("book_isbn") 
    account_id= request.form.get("account_id")
    session= Session()
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5 = []
    results = session.query(Cart).all()

    for i in results:

        if (str(id) in str(i.id)) is True:
            list1.append(i.id)
            list2.append(i.total)
            list3.append(i.purchase_date)
            list4.append(i.book_isbn)
            list5.append(i.account_id)
      
           
    session.commit()
    return render_template("cartresult.html", count=len(list1), result1=list1, result2=list2, result3= list3, result4= list4 ,result5=list5)
    


#2 route phục vụ chức năng create cho 2 bảng còn lại , thêm dữ liệu từ form do người dùng nhập
@app.route('/insert', methods=['POST'])
def insert():
        
    isbn= request.form['isbn']
    title= request.form['title']
    author= request.form['author']
    rating= request.form['rating']
    length= request.form['length']
    books=Store(isbn=isbn, title=title, author=author, rating=rating, length=length)
    session=Session()
    session.add(books) 
    session.commit()
    return redirect(url_for('store'))     


@app.route('/insert_cart', methods=['POST'])
def insert_cart():
        
    id= request.form['id']
    total= request.form['total']
    purchase_date= request.form['purchase_date']
    book_isbn= request.form['book_isbn']
    account_id= request.form['account_id']
    carts=Cart(id=id, total=total, purchase_date=purchase_date, book_isbn=book_isbn, account_id=account_id)
    session=Session()
    session.add(carts) 
    session.commit()
    return redirect(url_for('carts'))     
    

    
  #3 route này thực hiện chức năng update thông tin ,bằng cách request form cho người dùng nhập rồi gửi về csdl  
@app.route('/update', methods=["GET","POST"])
def update():

    session=Session()
    my_data = session.query(Store).get(request.form.get('isbn'))
    my_data.title=request.form['title']
    my_data.author=request.form['author']
    my_data.rating=request.form['rating']
    my_data.length=request.form['length']
    session.commit()
    return redirect(url_for('store'))


@app.route('/update_user', methods=["GET","POST"])
def update_user():

    session=Session()
    my_data = session.query(Account).get(request.form.get('id'))
    my_data.username=request.form['username']
    my_data.password=request.form['password']
    my_data.email=request.form['email']
    my_data.phone=request.form['phone']
    session.commit()
    return redirect(url_for('users'))


@app.route('/update_cart', methods=["GET","POST"])
def update_cart():

    session=Session()
    my_data = session.query(Cart).get(request.form.get('id'))
    my_data.total=request.form['total']
    my_data.purchase_date=request.form['purchase_date']
    my_data.book_isbn=request.form['book_isbn']
    my_data.account_id=request.form['account_id']
    session.commit()
    return redirect(url_for('carts'))



#3 route thực hiện việc xóa dữ liệu do người dùng chọn ra khỏi csdl
@app.route('/delete/<int:isbn>/', methods = ['GET', 'POST'])
def delete(isbn):

    session=Session()
    my_data = session.query(Store).get(isbn)
    session.delete(my_data)
    session.commit()
    flash("Xóa sách thành công")
    return redirect(url_for('store'))


@app.route('/delete_user/<int:id>/', methods = ['GET', 'POST'])
def delete_user(id):

    session=Session()
    my_users = session.query(Account).get(id)
    session.delete(my_users)
    session.commit()
    flash("Khử thành công")
    return redirect(url_for('users'))


@app.route('/delete_cart/<int:id>/', methods = ['GET', 'POST'])
def delete_cart(id):

    session=Session()
    my_users = session.query(Cart).get(id)
    session.delete(my_users)
    session.commit()
    flash("Giỏ hàng xóa thành công")
    return redirect(url_for('carts'))



if __name__ == '__main__':
    app.run(debug=True)
